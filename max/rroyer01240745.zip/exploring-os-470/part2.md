* Name: Max Royer
* Honor Code statement: On my honor, I affirm that I neither gave, nor witnessed, nor recieved any unauthorized assistance on this assignment.
* Collaboration statement: No AI was used for any part.



### Project writeup:
1. Question 1 (virtualization of the CPU):
---

The output when running multiple programs was pretty much as expected. The three programs executed what appeared to be (but was not) simultaneously, in the same order each time, H -> V -> S.


2. Question 2 (memory virtualization):

```(36050) addr pointed to by p: 0x424010
(36051) addr pointed to by p: 0x424010
(36052) addr pointed to by p: 0x424010
(36050) value of p: 1
(36051) value of p: 1
(36052) value of p: 1
(36050) value of p: 2
(36051) value of p: 2
(36052) value of p: 2
(36050) value of p: 3
(36051) value of p: 3
(36052) value of p: 3
(36050) value of p: 4
(36051) value of p: 4
(36052) value of p: 4
(36050) value of p: 5
(36051) value of p: 5
(36052) value of p: 5
(36050) value of p: 6
(36051) value of p: 6
(36052) value of p: 6
(36050) value of p: 7
(36051) value of p: 7
(36052) value of p: 7
(36050) value of p: 8
(36051) value of p: 8
(36052) value of p: 8
(36050) value of p: 9
(36051) value of p: 9
(36052) value of p: 9
(36050) value of p: 10
(36051) value of p: 10
(36052) value of p: 10
```



3. Question 3 (concurrency):

```
$./threads 10000000
Initial value : 0
Final value   : 15521375
```