# Part 1: Setup for the Semester and Learning Markdown

## Using markdown on GitHub and Codespaces

In industry, you often want to style documents, issues, pull requests, and files within a github repo. ["Markdown"](https://guides.github.com/features/mastering-markdown/) is an easy way to style documents with some simple syntax. This can be helpful to organize your information and make it easier for others to read. You can also drop in gifs and images to help convey your point!
To learn more about using GitHub’s flavor of markdown, read ["Basic Writing and Formatting Syntax"](https://docs.github.com/en/github/writing-on-github/basic-writing-and-formatting-syntax) or keep it handy as a reference.

## Part 1 Instructions
Introduce yourself via a markdown file. We'll be using markdown a lot during your assignments, so let's practice now.  

1. Create a new markdown file in your directory.
 `prompt> touch part1.md`
2. Open the file.  To do this, you can either type `code intro.md` at the command line or click on the file in the File Explorer pane (usually the left hand side).  Either of these will open your markdown file in editing mode.  This is not the rendered version of the markdown.
3. Type `#Your Name` in the `part1.md` file.  This is the body of your file.
4. Open the "Preview" version of your document by right-clicking your markdown tab and selecting "Open Preview".  There are other ways to do this as well.  You should see your name, but big and bold, like a document heading and without the `#`.
5. Add the following elements (see the Markdown guide earlier in this document for more help) each with a header for readability
   1. A table listing all the CMS courses you've take and what semester you took them.
   2. A bulleted list with questions you have about the course so far.
   3. A block of code (it can be any code you wish in any language, but it should be at least 3 lines long
   4. A numbered list which answers the following questions:
      1. Pretend you just got your dream job after graduation.  How are you using computer science in that career?
      2. Rank the following from your most-preferred to least-preferred use of class time:  Independent work time (for reading or working on homework or coding), lectures, independent group or pair activities (you're given a problem and you work on it without direct instructor interference), instructor-guided activities or problems (instructor demonstates, you follow along)
      3. Is there anything I should know about you or your situation this semester which might make it hard for you to be successful in this course?
6. You're finished with this part, so you can close all the tabs for your intro markdown document.

# Part 2: Introduction to OS Concepts

This part of the project is designed to allow you to see 3 fundamental pieces of the operating system in action:
* virtualization of the CPU
* virtualization of memory
* concurrency

It is designed to be easy.  Ask for help quickly if you are struggling or something goes wrong.  Your grade for this part will be determined by the answers in your `part2.md` file.

***Pro tip:** These concepts map to some early readings, so you may wish to skim those first to better understand what you're seeing in this part of the project.*


## Review:
Open the `Makefile` and refresh your memory about how a Makefile works.  What executables will be built when you type `make`?  See if you were correct by typing the `make` command at a prompt.  Then type `ls` to list all the files in the current directory.  How can you tell the difference between executables and source code files on your platform? (Hint: *you made need to turn on file extension visibility or look carefully at icons, depending on your development platform.*)  In this assignment, don't compile things directly using `gcc`.  Instead, use `make` and keep things simple. 

### Part 2a: Investigating CPU Virtualization
Open `cpu.c` and examine the code.  It doesn’t do much. In fact, all it does is call `Spin()`, a function that repeatedly checks the time and returns once it has run for a second. Then, it prints out the string that the user passed in on the command line, and repeats, forever (note the purposeful infinite loop!). 

Use the `cpu` program to make the OS run a single copy of the program to make sure everything is working:
```
prompt> ./cpu A
```
Since the program currently contains an infinite loop, it will run forever.  Use `Ctl-c` to kill it.

Our goal is to run multiple copies of the program at the same time and observe how the operating system switches between different running programs.  But first, let's make some modifications so the program doesn't run in an infinite loop -- otherwise, we'll have to kill/Ctl-C each program!
1. Add an `int` variable which makes the `while` loop run only 7 times instead of infinitely.  This variable can count up to 7 or down from 7; just make sure it only runs 7 times.
2. Modify the print statement inside the loop to include the `int` variables value in the form `number - process_name` instead of just `process_name` (which is currently passed via a command line argument.
3. Don't forget to modify the `int` variable each time the loop runs so you don't have an infinite loop.

Test and run your program frequently.  Remember that if you change your source code, you must recompile using `make`!  Don't proceed to the next step until you have removed the infinite loop.

4. Now, let's do the same thing, but this time, let's run many different instances of this same program.  We'll start by running 3 copies of our program (each with a different name) at the same time and watch how the OS changes control:
```
prompt> ./cpu V & ./cpu H & ./cpu S
```
The `&` causes the next program to immediately start running rather than waiting for the previous one to finish.  You should now get a series of output from all 3 programs intermingled.  However, each output should be identifiable based on the letter you supplied after the program name.  In the above example, I used the letters 'V', 'H', and 'S'; you should use your own initials if you want.  Just make sure the three letters are different so you can tell the processes apart.

**Checkpoint 1:**

Record your observations about the output displayed in the terminal in your `part2` file for `Question 1`.


### Part 2b: Investigating Memory Virtualization
Next, run `mem` (compiled from `mem.c`) and observe the ouput.  Again, this program contains an infinite loop, so you will need to use `Ctl-c` to end it.  You should see something like:

```
(43875) addr pointed to by p: 0x56bb54cbb2a0
(43875) value of p: 1
...
```

The program does a couple of things. First, it allocates some memory (line 8). Then, it prints out the address of the memory (line 10), and then
puts the number zero into the first slot of the newly allocated memory (line 11). Finally, it loops, delaying for a second and incrementing the value stored at the address held in `p`. With every print statement, it also prints out what is called the process identifier (the PID) of the running program -- the `(43875)` in the output above is the PID. This PID is unique per running process on the OS.

As we did in the other program, change `mem.c` to remove the infinite loop.  Change this program so that the loop runs **10 times**.  You don't need to add the counter variable to the output this time; it's fine to leave the output as it is.  Compile and test to ensure that your program automatically stops after 10 iterations.

Examine the output of your code and make sure you understand the output.  In particular, take a look at the **pid** (process id) and the address of `p`. Again, this first result is not too interesting.

At a prompt in the terminal, run the following command:
```
setarch $(uname --machine) --addr-no-randomize /bin/bash
```

I recommend you copy-paste this line to avoid typos.  This command will turn off address space randomization.  By the end of the semester, you'll understand why address randomization (a security feature) is important, but for now, don't worry about it.

Now, lets run 3 copies of this program at the same time.  At the prompt, type:
```
./mem & ./mem & ./mem
```

**Checkpoint 2:**

In your `part2.md` file for Question 2, copy and paste the output which shows that all three programs **appear** to be using the same address(es) to store data. Are the 3 programs actually using the same physical memory space even though that's what the output appears to show?  No. Take a moment to think about the concept of a *program's address space* you learned about in CMS 230 and how that concept might be applicable here.

Type `exit` at the prompt to re-enable address randomization.

### Part 2c: Investigating Concurrency
Now let's take a brief look at the topic of concurrency.  Concurrency is a bit different than just making multiple processes.  In the previous exercises, we just made multiple copies of a program.  In a concurrent program, we break the program's functionality up into discrete pieces and each pieces runs on its own *thread*.  However, each thread might share common resources (such as memory) within the overall structure of the program.

Open `threads.c`.  The program creates two threads and asks them to each run the function `worker` (lines 25-26) .  This function just loops and increments a variable as it does so (lines 9-15).  When a thread has finished, it ends.  The entire program doesn't print the final value of the variable (line 29) and end until all threads have finished.

You might think that thread 1 (`p1`) will run as many times as it needs to and then thread 2 (`p2`) would start and run as many times as it needs to.  But that's not the point of multi-threaded programs these days.  The point is that we want these threads to run *in parallel*, one on each core of our chip.  That makes our program faster and more efficient!

This program takes a command line argument.  The integer specified after the program name tells the program how many times each thread should increment the variable.  Begin by running the program with a small number, say 1000:
```
./threads 1000
```

Now run the program with 10000, 100000, 1000000, and 10000000 as arguments.  You will notice weird things happening as you run with larger and larger numbers.  For example, when we give an input value of 10,000,000, instead of getting a final value of 20,000,000, we instead first get 15,143,012 (or some other seemingly random number which is not 20,000,000). Then, when we run the program a second time, we not only again get the wrong value, but also a different value than the last time. In fact, if you run the program over and over with high values of loops, you may find that sometimes you even get the right answer! So why is this happening?

As it turns out, the reason for these odd and unusual outcomes relate to how instructions are executed, which is one at a time. Unfortunately, a
key part of program, where the shared variable `counter` is incremented, takes three low-level (assembly/machine) instructions: one to load the value of the counter from memory into a register, one to increment it, and one to store it back into memory. Because these three instructions do not execute atomically (all at
once), strange things can happen. It is this problem of concurrency that we will address in great detail later in the course.

**Checkpoint 3:**

For **Question 3**, copy a single run's output which shows the concurrency problem clearly (ie, a run which does not output the correct value).  Note that to clearly show this problem, you'll have to include your invocation of the program and the supplied command line argument.

## Submission
Before submitting run the command
`prompt> make clean`

This executes the `clean` rule in the Makefile and removes executables and linker (`.o`) files while retaining your source code, markdown files, etc.  Doing this before you zip your files for submission keeps the size of the files you submit to Canvas to a reasonable size.

Move up one directory:
`cd ..`
Then execute the command
`zip -r userID.zip directory_name/

This creates a zip file named `userID` with all the files from `directory_name` in it.  Obviously, you will need to substitute your Rollins userID and your directory name for the command.

Download this file from your Codespace (right click on it > Download) to your local computer.  Then upload the file to the correct assignment in Canvas.  I grade the last thing you submit, and you can submit as many times as you wish until the late turn-in deadline passes.



*This project is based on the OSTEP book, Chapter 2: http://pages.cs.wisc.edu/~remzi/OSTEP/intro.pdf*
