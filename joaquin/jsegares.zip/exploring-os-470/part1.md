# Joaquin Segares

## CMS Courses Taken

| Course | Semester |
|--------|----------|
| CMS 120 | Fall 2023 |
| CMS 120L | Fall 2023 |
| CMS 121 | Spring 2024 |
| CMS 230 | Spring 2025 |
| CMS 250 | Fall 2024 |
| CMS 270 | Fall 2024 |
| CMS 470 | Fall 2026 |
| CMS 484 | Fall 2026 |

## Questions About the Course

- I always wanted to know what CMS professors think about the rise of AI lately such as Claude Code, Codex, and other plug in programms.
- How long are the quizzes?
- Are the quiz quesitons mostly like the ones from the readings?

## Sample Code

```python
def greet(name):
    print(f"Hello, {name}!")

greet("World")
```

## Reflection

1. So lets say i jsut got my dream job after gradutation. I graduate May of 2027, and by then AI is even more powerfull than now. Realitically, or at least in my opinion, most companies would have already started having their developers use AI to code, which in my opinion is perfectly fine, we do get job done way faster, but my degree would differentiate myself to regular people because of the knowledge I know, it wouldnt just make me a vibecoder AI guy. The title would say I know what im talking about and the hows and the whys im using whatever im using.
2. My prefferd thing about class time for this class would be a quick lecture/summary of the reading, because sometimes I have so many doubts after reading, and it really does help me whent he professor explains it in her own words than just reading.
3. Something about me this semester is that I am taking six classes, im not saying this as an excuse, it'll just be a lot of workload sometimes, but i will still give it my best on all the assignments.