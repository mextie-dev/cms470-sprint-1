* Name: Joaquin Segares 
* Honor Code statement: “On my honor, I have not given, nor received, nor witnessed any unauthorized assistance on this work.”
* Collaboration statement: AI helped me with the assignment in the sense that i worked with it step by step and it went explaining it little by little to me so i can understand better since ive been having trouble with this topic.



### Project writeup:
1. Question 1 (virtualization of the CPU):
@chapatjn ➜ /workspaces/codespaces-blank/exploring-os-470 $ ./cpu V & ./cpu H & ./cpu S
[1] 2472
[2] 2473
0 - H
0 - S
0 - V
1 - S
1 - H
1 - V
2 - S
2 - H
2 - V
3 - S
3 - H
3 - V
4 - S
4 - V
4 - H
5 - S
5 - V
5 - H
6 - V
6 - S
6 - H
[1]-  Done                    ./cpu V
[2]+  Done                    ./cpu H

This is really interesting, so each program doesnt know the other one exists, but the OS is creating the illuson. Spin (1) makes each program run for a second and then gets paused so the others can run. This is the OS' scheduler performing CPU Virtualization.

2. Question 2 (memory virtualization):
@chapatjn ➜ /workspaces/codespaces-blank/exploring-os-470 $ ./mem & ./mem & ./mem
[1] 11665
[2] 11666
(11665) addr pointed to by p: 0x5555555592a0
(11667) addr pointed to by p: 0x5555555592a0
(11666) addr pointed to by p: 0x5555555592a0
(11665) value of p: 1
(11667) value of p: 1
(11666) value of p: 1
(11665) value of p: 2
(11667) value of p: 2
(11666) value of p: 2
(11665) value of p: 3
(11666) value of p: 3
(11667) value of p: 3
(11665) value of p: 4
(11666) value of p: 4
(11667) value of p: 4
(11665) value of p: 5
(11666) value of p: 5
(11667) value of p: 5
(11665) value of p: 6
(11666) value of p: 6
(11667) value of p: 6
(11665) value of p: 7
(11666) value of p: 7
(11667) value of p: 7
(11665) value of p: 8
(11666) value of p: 8
(11667) value of p: 8
(11665) value of p: 9
(11666) value of p: 9
(11667) value of p: 9
(11665) value of p: 10
(11666) value of p: 10
(11667) value of p: 10
[1]-  Done                    ./mem
[2]+  Done                    ./mem

So what is happening here is all three processes printed the same address for p and each alone counted from 1 to 10 without interference from the others. This is because the printed address is virtual not physical. Each process gets its own "private virtual space" and the OS and Hardware maps that same looking virtual address to a different physucal memory locaiton for each process, so they are not actually sharing memory they jsut look like they are.

3. Question 3 (concurrency):
@chapatjn ➜ /workspaces/codespaces-blank/exploring-os-470 $ ./threads 10000000
./threads 10000000
Initial value : 0
Final value   : 13206335
Initial value : 0
Final value   : 14380412

Instead of the expected 20,000,000 the final value is wrong. This happens because counter ++ is not final, it compiles into three steps: load counter into a registar, increment it, and store it in the back. Since both threads share the same counter and the scheduler can interrupt either thread mid-sequence, one thread cna load a stale vlaue after the other thread already updatedcounter but before writing it back causing an increment to be lost. 
