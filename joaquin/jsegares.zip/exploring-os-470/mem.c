#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "common.h"

int main(int argc, char *argv[]) {
 
    int *p = malloc(sizeof(int));
    assert(p != NULL);
    printf("(%d) addr pointed to by p: %p\n", (int) getpid(), p);
    *p = 0;
    
    int i = 0;
while (i < 10) {
	    Spin(1);
        i++; 
	    *p = *p + 1;
	    printf("(%d) value of p: %d\n", getpid(), *p);
    }
    return 0;
}
