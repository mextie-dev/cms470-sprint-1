#include <stdio.h>
#include <stdlib.h>
#include "common.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
    	fprintf(stderr, "usage: cpu <string>\n");
	    exit(1);
    }
    char *str = argv[1];

    int i = 0;
while (i < 7) {
    printf("%d - %s\n", i, str);
    Spin(1);
    i++;
}
    return 0;
}
